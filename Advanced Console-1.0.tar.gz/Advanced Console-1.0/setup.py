from distutils.core import setup
setup(name='Advanced Console',
      version='1.0',
      py_modules=['Advancedconsole'],
      )